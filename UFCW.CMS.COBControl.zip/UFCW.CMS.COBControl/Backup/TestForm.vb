

Public Class TestForm

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Private Sub Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonRefresh.Click

        COBDS.Clear()
        COBDS = CType(CMSDALFDBMD.RetrieveCOBInfo(CType(Me.FamilyID.Text.ToString, Integer), CType(Me.RelationID.Text.Trim, Short), COBDS), UI.COBDataSet)

        CobControl1.ClearAll()

        Me.CobControl1.ReadOnlyMode = CBool(ReadOnlyCheckBox.CheckState = CheckState.Checked)
        CobControl1.COBDataSet = COBDS

        Me.CobControl1.LoadCOB(CType(Me.FamilyID.Text.ToString, Integer), If(Me.RelationID.Text.Trim.Length > 0, CType(Me.RelationID.Text.Trim, Short?), Nothing))

    End Sub

    Private Sub ButtonClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ButtonClear.Click

        Me.CobControl1.ClearAll()

    End Sub

#End Region
End Class