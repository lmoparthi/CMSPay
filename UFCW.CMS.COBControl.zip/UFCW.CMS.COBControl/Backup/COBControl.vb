Option Strict On

Imports System.ComponentModel

Imports DDTek.DB2
Imports System.Security.Principal
Imports System.Data.Common

Public Class COBControl
    Inherits System.Windows.Forms.UserControl

    Private Shared _TraceSwitch As New BooleanSwitch("TraceCloning", "Trace Switch in App.Config")

    Private _FamilyID As Integer = -1
    Private _RelationID As Short? = Nothing
    Private _ClaimID As Integer = -1
    Private _ReadOnlyMode As Boolean = False

    Private ReadOnly _WindowsUserID As WindowsIdentity = WindowsIdentity.GetCurrent()
    Private _WindowsPrincipalForID As WindowsPrincipal = New WindowsPrincipal(_WindowsUserID)

    Private _APPKEY As String = "UFCW\Claims\"
    Private _COBBindingManagerBase As BindingManagerBase

    'Public Event BeforeRefresh(ByVal sender As Object, ByRef Cancel As Boolean)
    'Public Event AfterRefresh(ByVal sender As Object)

    ReadOnly _DomainUser As String = SystemInformation.UserName

    Public Overloads Sub Dispose()

        If COBDataGrid.DataSource IsNot Nothing AndAlso COBDataGrid.DataSource IsNot Nothing Then

            SaveSettings()

            COBDataGrid.Dispose()
        End If
        COBDataGrid = Nothing
        MyBase.Dispose()
    End Sub

#Region "Constructor"

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Dim TheDesignMode As Boolean = (LicenseManager.UsageMode = LicenseUsageMode.Designtime)

        If Not TheDesignMode Then
            PreLoad()
        End If

    End Sub
    Public Sub PreLoad()

        Try

            'dont want to display the default table style
            COBDataGrid.TableStyles.Clear()

            ClearCOBDataBindings()

            CMSDALFDBMD.RetrievePayers(COBDS)

            COBDS.RELATIONSHIP_VALUES.Clear()

            Dim NewRow As UI.COBDataSet.RELATIONSHIP_VALUESRow
            NewRow = COBDS.RELATIONSHIP_VALUES.NewRELATIONSHIP_VALUESRow
            NewRow(0) = ""
            NewRow(1) = DBNull.Value

            COBDS.RELATIONSHIP_VALUES.Rows.Add(NewRow)
            COBDS.RELATIONSHIP_VALUES.Merge(CMSDALFDBMD.RetrieveRelationShipValues())

            COBDS.AcceptChanges() 'prevents dataset haschanges validation from failing

            ProcessControls(Me, True) ' disable UI Input elements until a row is added

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Public Sub New(ByVal familyID As Integer, ByVal relationID As Short?)
        Me.New()

        _FamilyID = familyID
        _RelationID = relationID
        _ClaimID = -1

    End Sub
    Public Sub New(ByVal familyID As Integer, ByVal relationID As Short?, ByVal claimID As Integer)
        Me.New()

        _FamilyID = familyID
        _RelationID = relationID
        _ClaimID = claimID

    End Sub

#End Region

#Region "Properties"
    <System.ComponentModel.Browsable(True), System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), System.ComponentModel.Description("Determines if control is in Read Only Mode.")> _
    Public Property ReadOnlyMode() As Boolean
        Get
            Return _ReadOnlyMode
        End Get
        Set(ByVal value As Boolean)
            _ReadOnlyMode = Value
        End Set
    End Property

    <System.ComponentModel.Browsable(False), System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), System.ComponentModel.Description("Indicates that Save has not been used.")> _
    Public ReadOnly Property ChangesPending() As Boolean
        Get
            Return COBDS.HasChanges
        End Get
    End Property

    <System.ComponentModel.Browsable(False), System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), System.ComponentModel.Description("Gets or Sets the FamilyID of the Document.")> _
    Public Property FamilyID() As Integer
        Get
            Return _FamilyID
        End Get
        Set(ByVal value As Integer)
            _FamilyID = Value
        End Set
    End Property

    <System.ComponentModel.Browsable(False), System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), System.ComponentModel.Description("Gets or Sets the FamilyID of the Document.")> _
    Public Property ClaimID() As Integer
        Get
            Return _ClaimID
        End Get
        Set(ByVal value As Integer)
            _ClaimID = Value
        End Set
    End Property

    <System.ComponentModel.Browsable(False), System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), System.ComponentModel.Description("Gets or Sets the FamilyID of the Document.")> _
    Public Property RelationID() As Short?
        Get
            Return _RelationID
        End Get
        Set(ByVal value As Short?)
            _RelationID = value
        End Set
    End Property

    <System.ComponentModel.Browsable(False), System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden), System.ComponentModel.Description("Can provide COB data to process for caching purpose")> _
    Public Property COBDataSet() As UI.COBDataSet
        Get
            Return COBDS
        End Get
        Set(ByVal value As UI.COBDataSet)
            COBDS.Clear()
            COBDS.Merge(value)
        End Set
    End Property

    <Browsable(True), System.ComponentModel.Description("Gets or Sets the AppKey to use when saving control information.")> _
    Public Property AppKey() As String
        Get
            Return _APPKEY
        End Get
        Set(ByVal value As String)
            _APPKEY = Value
        End Set
    End Property
#End Region

#Region "Custom Subs\Functions"

    Public Sub LoadCOB(ByVal theFamilyID As Integer, ByVal theRelationID As Short?)
        Try
            _FamilyID = theFamilyID
            _RelationID = theRelationID

            LoadCOB()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Public Sub LoadCOB(ByVal theFamilyID As Integer, ByVal theRelationID As Short?, ByVal theClaimID As Integer)
        Try
            _FamilyID = theFamilyID
            _RelationID = theRelationID
            _ClaimID = theClaimID

            LoadCOB()

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Public Sub LoadCOB()

        Try

            ClearErrors()
            ClearCOBDataBindings()

            If COBDS.Tables("MEDOTHER_INS").Rows.Count < 1 Then 'Data may have been provided to control, so don't repeat data retrieval
                COBDS = CType(CMSDALFDBMD.RetrieveCOBInfo(_FamilyID, CShort(If(_RelationID Is Nothing, 0S, _RelationID)), COBDS), UI.COBDataSet)
                COBDS = CType(CMSDALFDBMD.RetrievePayers(COBDS), UI.COBDataSet)
            End If

            COBDataGrid.DataMember = ""
            COBDataGrid.DataSource = COBDS.MEDOTHER_INS
            COBDS.Tables("MEDOTHER_INS").DefaultView.Sort = If(COBDataGrid.LoadSortByColumnName(_AppKey, COBDataGrid.Name & "\" & COBDataGrid.GetCurrentDataTable.TableName & "\Sort", COBDS.Tables(0)).ToString.Trim.Length = 0, "OCC_FROM_DATE DESC", COBDataGrid.LoadSortByColumnName(_AppKey, COBDataGrid.Name & "\" & COBDataGrid.GetCurrentDataTable.TableName & "\Sort", COBDS.Tables("MEDOTHER_INS"))).ToString

            COBDataGrid.SetTableStyle()

            LoadCOBDataBindings()

            SetNonBoundItems()
            SetUINavigation()

            ProcessControls(Me, _ReadOnlyMode, False)

            If Not _ReadOnlyMode AndAlso COBDS.Tables("MEDOTHER_INS").Rows.Count < 1 Then
                ProcessControls(Me, True, True) ' disable UI Input elements until a row is added
            End If

            SaveButton.Enabled = False
            CancelButton.Enabled = False

        Catch ex As Exception
            Throw
        Finally

            If _COBBindingManagerBase.Position > -1 Then COBDataGrid.Select(_COBBindingManagerBase.Position)

        End Try
    End Sub

    Private Sub ProcessControls(ByVal ctrl As Control, ByVal isReadOnlyMode As Boolean, Optional ByVal dataRelatedRequest As Boolean = False)

        Try

            '  Ignore the control unless it's a textbox.
            If TypeOf (ctrl) Is TextBox Then
                CType(ctrl, TextBox).ReadOnly = isReadOnlyMode
            ElseIf TypeOf (ctrl) Is ComboBox Then
                CType(ctrl, ComboBox).Visible = Not isReadOnlyMode
            ElseIf TypeOf (ctrl) Is Button AndAlso ctrl.Text <> "History" AndAlso Not DataRelatedRequest Then
                CType(ctrl, Button).Visible = Not isReadOnlyMode
            ElseIf TypeOf (ctrl) Is Panel AndAlso CType(ctrl, Panel).Name = "CheckboxPanel" Then
                CType(ctrl, Panel).Enabled = Not isReadOnlyMode
            End If

            '  Process controls recursively.  This is required
            '  if controls contain other controls (for
            '  example, if you use panels, group boxes, or other
            '  container controls).
            For Each ctrlChild As Control In ctrl.Controls
                ProcessControls(ctrlChild, isReadOnlyMode, DataRelatedRequest)
            Next

            If Not _ReadOnlyMode Then Me.AddButton.Enabled = True
            If _ReadOnlyMode AndAlso dataRelatedRequest Then
                Me.CancelButton.Enabled = False
                Me.SaveButton.Enabled = False
            End If

            If Not isReadOnlyMode Then
                Me.PayerTextBox.Visible = False
                Me.OTH_RELATIONTextBox.Visible = False
                Me.OTH_SEXTextBox.Visible = False
            Else
                Me.PayerTextBox.Visible = True
                Me.OTH_RELATIONTextBox.Visible = True
                Me.OTH_SEXTextBox.Visible = True
            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub ClearCOBDataBindings()

        If _COBBindingManagerBase IsNot Nothing Then
            _COBBindingManagerBase.SuspendBinding()
            RemoveHandler _COBBindingManagerBase.CurrentItemChanged, AddressOf COBBindingManagerBase_CurrentItemChanged
            RemoveHandler _COBBindingManagerBase.PositionChanged, AddressOf COBBindingManagerBase_PositionChanged
            RemoveHandler _COBBindingManagerBase.CurrentChanged, AddressOf COBBindingManagerBase_CurrentChanged
        End If

        RemoveHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
        RemoveHandler OTH_SEXComboBox.SelectedIndexChanged, AddressOf OTH_SEXComboBox_SelectedIndexChanged
        RemoveHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

        COBDataGrid.DataMember = ""
        COBDataGrid.DataSource = Nothing

        OCC_TO_DATETextBox.DataBindings.Clear()
        OCC_FROM_DATETextBox.DataBindings.Clear()
        UPDATE_REASONTextBox.DataBindings.Clear()
        WORKING_SPOUSE_SWCheckBox.DataBindings.Clear()
        OTH_INS_REFUSAL_SWCheckBox.DataBindings.Clear()
        OTH_PAT_ACCT_NBRTextBox.DataBindings.Clear()
        HICNTextBox.DataBindings.Clear()
        OTH_POLICYTextBox.DataBindings.Clear()
        PHONETextBox.DataBindings.Clear()
        OTH_SSNTextBox.DataBindings.Clear()
        OTH_FNAMETextBox.DataBindings.Clear()
        OTH_LNAMETextBox.DataBindings.Clear()
        OTH_SEXComboBox.DataBindings.Clear()
        OTH_SEXTextBox.DataBindings.Clear()
        OTH_RELATIONComboBox.DataBindings.Clear()
        OTH_RELATIONTextBox.DataBindings.Clear()
        OTH_DOBTextBox.DataBindings.Clear()
        DOCIDTextBox.DataBindings.Clear()
        OTH_SUB_ACCT_NBRTextBox.DataBindings.Clear()
        ADDRESS_LINE1TextBox.DataBindings.Clear()
        ADDRESS_LINE2TextBox.DataBindings.Clear()
        CITYTextBox.DataBindings.Clear()
        STATETextBox.DataBindings.Clear()
        ZIPTextBox.DataBindings.Clear()
        ZIP_4TextBox.DataBindings.Clear()
        COUNTRYTextBox.DataBindings.Clear()
        PHONETextBox.DataBindings.Clear()
        EXTENSION1TextBox.DataBindings.Clear()
        PayerComboBox.DataBindings.Clear()
        PayerTextBox.DataBindings.Clear()
        FamilyMembersWithOILabel.Text = ""

        PayerComboBox.DataSource = Nothing
        OTH_RELATIONComboBox.DataSource = Nothing

    End Sub

    Private Sub LoadCOBDataBindings()
        Dim Bind As Binding

        Try

            _COBBindingManagerBase = Me.BindingContext(COBDS.MEDOTHER_INS)

            FamilyMembersWithOILabel.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS_COUNT, "FAMILY_MEMBERS_WITH_OI")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            FamilyMembersWithOILabel.DataBindings.Add(Bind)

            AddHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
            AddHandler OTH_SEXComboBox.SelectedIndexChanged, AddressOf OTH_SEXComboBox_SelectedIndexChanged
            AddHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

            OCC_TO_DATETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OCC_TO_DATE", True, DataSourceUpdateMode.OnValidation)
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf DateOnlyBinding_Format
            AddHandler Bind.Parse, AddressOf DateOnlyBinding_Parse
            AddHandler Bind.BindingComplete, AddressOf DateOnlyBinding_BindingComplete
            OCC_TO_DATETextBox.DataBindings.Add(Bind)

            OCC_FROM_DATETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OCC_FROM_DATE", True, DataSourceUpdateMode.OnValidation)
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf DateOnlyBinding_Format
            AddHandler Bind.Parse, AddressOf DateOnlyBinding_Parse
            AddHandler Bind.BindingComplete, AddressOf DateOnlyBinding_BindingComplete
            OCC_FROM_DATETextBox.DataBindings.Add(Bind)

            OTH_DOBTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_DOB", True, DataSourceUpdateMode.OnValidation)
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf DateOnlyBinding_Format
            AddHandler Bind.Parse, AddressOf DateOnlyBinding_Parse
            AddHandler Bind.BindingComplete, AddressOf DateOnlyBinding_BindingComplete
            OTH_DOBTextBox.DataBindings.Add(Bind)

            UPDATE_REASONTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "UPDATE_REASON")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            UPDATE_REASONTextBox.DataBindings.Add(Bind)

            OTH_INS_REFUSAL_SWCheckBox.DataBindings.Clear()
            Bind = New Binding("Checked", COBDS.MEDOTHER_INS, "OTH_INS_REFUSAL_SW")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            OTH_INS_REFUSAL_SWCheckBox.DataBindings.Add(Bind)

            Try

                WORKING_SPOUSE_SWCheckBox.DataBindings.Clear()
                Bind = New Binding("Checked", COBDS.MEDOTHER_INS, "WORKING_SPOUSE_SW")
                Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
                WORKING_SPOUSE_SWCheckBox.DataBindings.Add(Bind)
            Catch ex As Exception
                WORKING_SPOUSE_SWCheckBox.DataBindings.Clear()
                Bind = New Binding("Checked", COBDS.MEDOTHER_INS, "WORKING_SPOUSE_SW")
                Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
                AddHandler Bind.Format, AddressOf CheckBoxBinding_Format
                AddHandler Bind.Parse, AddressOf CheckBoxBinding_Parse
                WORKING_SPOUSE_SWCheckBox.DataBindings.Add(Bind)
            End Try

            OTH_PAT_ACCT_NBRTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_PAT_ACCT_NBR")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf UCaseBinding_Format
            AddHandler Bind.Parse, AddressOf UCaseBinding_Parse
            OTH_PAT_ACCT_NBRTextBox.DataBindings.Add(Bind)

            HICNTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "HICN")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf UCaseBinding_Format
            AddHandler Bind.Parse, AddressOf UCaseBinding_Parse
            HICNTextBox.DataBindings.Add(Bind)

            OTH_POLICYTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_POLICY")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf UCaseBinding_Format
            AddHandler Bind.Parse, AddressOf UCaseBinding_Parse
            OTH_POLICYTextBox.DataBindings.Add(Bind)

            PHONETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_TAXID")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            PHONETextBox.DataBindings.Add(Bind)

            OTH_SSNTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_SSN")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf SSNBinding_Format
            AddHandler Bind.Parse, AddressOf SSNBinding_Parse
            OTH_SSNTextBox.DataBindings.Add(Bind)

            OTH_FNAMETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_FNAME")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf UCaseBinding_Format
            AddHandler Bind.Parse, AddressOf UCaseBinding_Parse
            OTH_FNAMETextBox.DataBindings.Add(Bind)

            OTH_LNAMETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_LNAME")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf UCaseBinding_Format
            AddHandler Bind.Parse, AddressOf UCaseBinding_Parse
            OTH_LNAMETextBox.DataBindings.Add(Bind)

            DOCIDTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "DOCID")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Parse, AddressOf Numeric2NullBinding_Parse
            DOCIDTextBox.DataBindings.Add(Bind)

            OTH_SUB_ACCT_NBRTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "OTH_SUB_ACCT_NBR")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            OTH_SUB_ACCT_NBRTextBox.DataBindings.Add(Bind)

            ADDRESS_LINE1TextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "ADDRESS_LINE1")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            ADDRESS_LINE1TextBox.DataBindings.Add(Bind)

            ADDRESS_LINE2TextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "ADDRESS_LINE2")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            ADDRESS_LINE2TextBox.DataBindings.Add(Bind)

            CITYTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "CITY")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            CITYTextBox.DataBindings.Add(Bind)

            STATETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "STATE")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            STATETextBox.DataBindings.Add(Bind)

            ZIPTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "ZIP", True, DataSourceUpdateMode.OnValidation)
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf LeadingZeroesSize5Binding_Format
            AddHandler Bind.Parse, AddressOf Numeric2NullBinding_Parse
            ZIPTextBox.DataBindings.Add(Bind)

            ZIP_4TextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "ZIP_4")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Format, AddressOf LeadingZeroesSize4Binding_format
            AddHandler Bind.Parse, AddressOf Numeric2NullBinding_Parse
            ZIP_4TextBox.DataBindings.Add(Bind)

            COUNTRYTextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "COUNTRY")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            COUNTRYTextBox.DataBindings.Add(Bind)

            PHONETextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "PHONE")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Parse, AddressOf Numeric2NullBinding_Parse
            PHONETextBox.DataBindings.Add(Bind)

            EXTENSION1TextBox.DataBindings.Clear()
            Bind = New Binding("Text", COBDS.MEDOTHER_INS, "EXTENSION1")
            Bind.DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged
            AddHandler Bind.Parse, AddressOf Numeric2NullBinding_Parse
            EXTENSION1TextBox.DataBindings.Add(Bind)

            AddHandler _COBBindingManagerBase.CurrentItemChanged, AddressOf COBBindingManagerBase_CurrentItemChanged
            AddHandler _COBBindingManagerBase.PositionChanged, AddressOf COBBindingManagerBase_PositionChanged
            AddHandler _COBBindingManagerBase.CurrentChanged, AddressOf COBBindingManagerBase_CurrentChanged

            RemoveHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged
            Me.PayerComboBox.DataSource = Me.PAYERVALUESBindingSource
            Me.PayerComboBox.DisplayMember = "PAYER_NAME"
            AddHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

            RemoveHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
            Me.OTH_RELATIONComboBox.DataSource = Me.RELATIONSHIPVALUESBindingSource
            Me.OTH_RELATIONComboBox.DisplayMember = "DESCRIPTION"
            AddHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged

            _COBBindingManagerBase.ResumeBinding()

        Catch ex As Exception
            Throw
        Finally

        End Try

    End Sub

    Private Sub SetUINavigation()
        Dim CM As CurrencyManager

        Try

            CM = CType(_COBBindingManagerBase, CurrencyManager)

            PrevButton.Enabled = False
            NextButton.Enabled = False
            DeleteButton.Enabled = False

            If CM.Count > 0 Then

                If CM.Position < 1 AndAlso CM.Count > 1 Then
                    NextButton.Enabled = True
                ElseIf CM.Position = CM.Count - 1 AndAlso CM.Count > 1 Then
                    PrevButton.Enabled = True
                ElseIf CM.Count > 1 Then
                    PrevButton.Enabled = True
                    NextButton.Enabled = True
                End If

                DeleteButton.Enabled = True
                AddButton.Enabled = True

                ProcessControls(Me, False, True)

            Else

                ProcessControls(Me, True, True)
            End If

        Catch ex As Exception
            Throw
        Finally

            Dim ChangedCOBRows As UI.COBDataSet = CType(COBDS.GetChanges(), UI.COBDataSet)

        End Try

    End Sub

    Private Sub SetUIDataAwareness()
        Dim DR As DataRow
        Dim CM As CurrencyManager

        Try

            CM = CType(_COBBindingManagerBase, CurrencyManager)

            If CM.Count > 0 Then

                DR = DirectCast(CM.Current, DataRowView).Row
                If DR.RowState <> DataRowState.Unchanged Then
                    SaveButton.Enabled = True
                    CancelButton.Enabled = True

                    ProcessControls(Me, _ReadOnlyMode, True)

                End If

            End If

        Catch ex As Exception
            Throw
        Finally

            Dim ChangedCOBRows As UI.COBDataSet = CType(COBDS.GetChanges(), UI.COBDataSet)

        End Try

    End Sub

    Private Sub SetNonBoundItems()
        Dim CM As CurrencyManager

        Try

            CM = CType(_COBBindingManagerBase, CurrencyManager)

            If CM.Count > 0 Then

                Dim DR As DataRow = DirectCast(CM.Current, DataRowView).Row
                If Not IsDBNull(DR("OTH_SEX")) AndAlso DR("OTH_SEX").ToString.Trim.Length > 0 Then
                    OTH_SEXTextBox.Text = DR("OTH_SEX").ToString
                    OTH_SEXComboBox.SelectedItem = DR("OTH_SEX")
                    OTH_SEXComboBox.SelectedValue = DR("OTH_SEX")
                Else
                    OTH_SEXTextBox.Text = ""
                    OTH_SEXComboBox.SelectedIndex = -1
                End If

                If Not IsDBNull(DR("OTH_RELATION")) AndAlso DR("OTH_RELATION").ToString.Trim.Length > 0 Then
                    OTH_RELATIONTextBox.Text = DR("DESCRIPTION").ToString
                    OTH_RELATIONComboBox.Text = DR("DESCRIPTION").ToString
                    OTH_RELATIONComboBox.SelectedValue = DR("OTH_RELATION")
                Else
                    OTH_RELATIONTextBox.Text = ""
                    OTH_RELATIONComboBox.SelectedIndex = -1
                End If

                If Not IsDBNull(DR("PAYER_NAME")) Then
                    PayerTextBox.Text = DR("PAYER_NAME").ToString
                    PayerComboBox.Text = DR("PAYER_NAME").ToString
                    PayerComboBox.SelectedValue = DR("OTH_PAYER_ID")
                Else
                    PayerComboBox.SelectedIndex = -1
                End If

            Else

                PayerTextBox.Text = ""
                PayerComboBox.SelectedIndex = -1

                OTH_SEXTextBox.Text = ""
                OTH_RELATIONTextBox.Text = ""

            End If

        Catch ex As Exception
            Throw
        Finally

            Dim ChangedCOBRows As UI.COBDataSet = CType(COBDS.GetChanges(), UI.COBDataSet)

        End Try

    End Sub

    Private Sub COBBindingManagerBase_CurrentChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Try

            SetNonBoundItems()
            If Not _ReadOnlyMode Then SetUINavigation()

        Catch ex As Exception
            Throw
        End Try

    End Sub
    Private Sub COBBindingManagerBase_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Try

            If Not _ReadOnlyMode Then SetUINavigation()

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub COBBindingManagerBase_CurrentItemChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Try

            SetUIDataAwareness()

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub PayerComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Dim DR As DataRow

        Try

            If _COBBindingManagerBase IsNot Nothing AndAlso _COBBindingManagerBase.Count > 0 AndAlso CType(sender, ComboBox).SelectedIndex > -1 Then
                DR = DirectCast(_COBBindingManagerBase.Current, DataRowView).Row

                If IsDBNull(DR("PAYER_NAME")) OrElse (Not IsDBNull(DR("PAYER_NAME")) AndAlso Not DR("PAYER_NAME").ToString.Equals(CType(sender, ComboBox).Text)) Then
                    DR("PAYER_NAME") = CType(sender, ComboBox).Text
                End If

                If IsDBNull(DR("OTH_PAYER_ID")) OrElse (Not IsDBNull(DR("OTH_PAYER_ID")) AndAlso Not DR("OTH_PAYER_ID").ToString.Equals(If(IsNothing(CType(sender, ComboBox).SelectedValue), Nothing, CType(sender, ComboBox).SelectedValue.ToString))) Then
                    DR("OTH_PAYER_ID") = If(IsNothing(CType(sender, ComboBox).SelectedValue), DBNull.Value, CType(sender, ComboBox).SelectedValue)
                End If

                Me.ToolTip1.SetToolTip(Me.PayerComboBox, CType(sender, ComboBox).Text)

                ErrorProvider1.SetError(InsurerFreeFormButton, "")
                ErrorProvider1.SetError(PayerComboBox, "")

                InsurerFreeFormButton.Enabled = False

                Me.ToolTip1.SetToolTip(Me.InsurerFreeFormButton, "")

                Select Case DR("PAYER_NAME").ToString.Trim.ToUpper.ToString
                    Case "OTHER"
                        InsurerFreeFormButton.Enabled = True

                        If IsDBNull(DR("OTH_COMMENTS")) OrElse DR("OTH_COMMENTS").ToString.Trim.Length = 0 Then
                            ErrorProvider1.SetError(Me.InsurerFreeFormButton, " Must select a Insurer")
                            Me.ToolTip1.SetToolTip(Me.InsurerFreeFormButton, "")
                        Else
                            Me.ToolTip1.SetToolTip(Me.InsurerFreeFormButton, DR("OTH_COMMENTS").ToString)
                        End If

                    Case Nothing

                        ErrorProvider1.SetError(CType(sender, ComboBox), " Must Provide a Insurer")

                End Select

            End If

        Catch ex As Exception
            Throw
        Finally

        End Try

    End Sub

    Private Sub OTH_SEXComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Dim DR As DataRow

        Try

            If _COBBindingManagerBase IsNot Nothing AndAlso _COBBindingManagerBase.Count > 0 AndAlso _COBBindingManagerBase.Position > -1 Then
                DR = DirectCast(_COBBindingManagerBase.Current, DataRowView).Row
                If Not DR("OTH_SEX").ToString.Equals(CType(sender, ComboBox).Text) Then
                    DR("OTH_SEX") = CType(sender, ComboBox).Text
                End If
            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub OTH_RELATIONComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        Dim DR As DataRow

        Try

            If _COBBindingManagerBase IsNot Nothing AndAlso _COBBindingManagerBase.Count > 0 AndAlso _COBBindingManagerBase.Position > -1 Then
                DR = DirectCast(_COBBindingManagerBase.Current, DataRowView).Row
                If Not DR("DESCRIPTION").ToString.Equals(CType(sender, ComboBox).Text) Then

                    DR("DESCRIPTION") = CType(sender, ComboBox).Text
                    DR("OTH_RELATION") = CType(sender, ComboBox).SelectedValue

                    SaveButton.Enabled = True
                    CancelButton.Enabled = True

                End If
            End If

        Catch ex As Exception
            Throw
        Finally
        End Try

    End Sub

    Private Sub DataBinding_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles OTH_DOBTextBox.Validated,
                                                                                                    OTH_RELATIONComboBox.Validated,
                                                                                                    OTH_SEXComboBox.Validated,
                                                                                                    PayerComboBox.Validated,
                                                                                                    OCC_FROM_DATETextBox.Validated,
                                                                                                    OCC_TO_DATETextBox.Validated,
                                                                                                    OTH_FNAMETextBox.Validated,
                                                                                                    OTH_LNAMETextBox.Validated,
                                                                                                    OTH_PAT_ACCT_NBRTextBox.Validated,
                                                                                                    HICNTextBox.Validated,
                                                                                                    OTH_POLICYTextBox.Validated,
                                                                                                    OTH_RELATIONComboBox.Validated,
                                                                                                    OTH_SEXComboBox.Validated,
                                                                                                    OTH_SSNTextBox.Validated,
                                                                                                    UPDATE_REASONTextBox.Validated,
                                                                                                    DOCIDTextBox.Validated,
                                                                                                    PHONETextBox.Validated,
                                                                                                    OTH_SSNTextBox.Validated,
                                                                                                    OTH_SUB_ACCT_NBRTextBox.Validated,
                                                                                                    ADDRESS_LINE1TextBox.Validated,
                                                                                                    ADDRESS_LINE2TextBox.Validated,
                                                                                                    CITYTextBox.Validated,
                                                                                                    STATETextBox.Validated,
                                                                                                    ZIPTextBox.Validated,
                                                                                                    ZIP_4TextBox.Validated,
                                                                                                    COUNTRYTextBox.Validated,
                                                                                                    PHONETextBox.Validated,
                                                                                                    EXTENSION1TextBox.Validated

        '    Private Sub DataBinding_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles OCC_FROM_DATETextBox.Validated, OCC_TO_DATETextBox.Validated, OTH_RELATIONComboBox.Validated, OTH_SEXComboBox.Validated, UPDATE_REASONTextBox.Validated, DOCIDTextBox.Validated

        Try

            If ErrorProviderErrorsList(ErrorProvider1).Length = 0 AndAlso COBDS.MEDOTHER_INS IsNot Nothing AndAlso _COBBindingManagerBase IsNot Nothing Then
                _COBBindingManagerBase.EndCurrentEdit()
                BindingContext(COBDS.MEDOTHER_INS).EndCurrentEdit()

                If COBDataGrid IsNot Nothing Then COBDataGrid.RefreshData()
            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Public Sub ClearAll()

        SaveSettings()

        ClearCOBDataBindings()

        COBDS.Clear()
        COBDS.AcceptChanges()

        ClearErrors()

        PayerComboBox.SelectedIndex = -1
        OTH_RELATIONComboBox.SelectedIndex = -1
        OTH_SEXComboBox.SelectedIndex = -1

        SaveButton.Enabled = False
        CancelButton.Enabled = False
        NextButton.Enabled = False
        PrevButton.Enabled = False
        AddButton.Enabled = False
        DeleteButton.Enabled = False

        ProcessControls(Me, True, True) ' disable UI Input elements until a row is added

    End Sub

    Public Sub SaveSettings()

        Try

            If COBDataGrid IsNot Nothing Then
                If COBDataGrid.GetCurrentDataTable IsNot Nothing Then
                    COBDataGrid.SaveColumnsSizeAndPosition(_AppKey, COBDataGrid.Name & "\" & COBDataGrid.GetCurrentDataTable.TableName & "\ColumnSettings")
                    COBDataGrid.SaveSortByColumnName(_AppKey, COBDataGrid.Name & "\" & COBDataGrid.GetCurrentDataTable.TableName & "\Sort", COBDataGrid.GetGridSortColumn)
                End If
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' moves the current index and displays in the edit window the previous row
    ' </summary>
    ' <param name="sender"></param>
    ' <param name="e"></param>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[Nick Snyder]	4/11/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------
    Private Sub PrevButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrevButton.Click
        Try

            _COBBindingManagerBase.EndCurrentEdit()

            If _COBBindingManagerBase.Position > -1 Then
                If VerifyCOBChanges() Then
                    Exit Sub
                End If

                _COBBindingManagerBase.Position -= 1

            End If

        Catch ex As Exception
            Throw
        Finally

            COBDataGrid.Select(_COBBindingManagerBase.Position)

        End Try
    End Sub

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' moves the current index and displays in the edit window the next row
    ' </summary>
    ' <param name="sender"></param>
    ' <param name="e"></param>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[Nick Snyder]	4/11/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------
    Private Sub NextButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NextButton.Click

        Try

            _COBBindingManagerBase.EndCurrentEdit()

            If _COBBindingManagerBase.Position > -1 Then
                If VerifyCOBChanges() Then
                    Exit Sub
                End If

                _COBBindingManagerBase.Position += 1
            End If

        Catch ex As Exception
            Throw
        Finally

            COBDataGrid.Select(_COBBindingManagerBase.Position)

        End Try
    End Sub

    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click

        Try
            RemoveHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
            RemoveHandler OTH_SEXComboBox.SelectedIndexChanged, AddressOf OTH_SEXComboBox_SelectedIndexChanged
            RemoveHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

            AddButton.Enabled = False

            If _COBBindingManagerBase.Count > 0 Then

                If VerifyCOBChanges() Then
                    Return
                End If

            End If

            AddCOBLine()

            PayerComboBox.SelectedIndex = -1
            OTH_RELATIONComboBox.SelectedIndex = -1
            OTH_SEXComboBox.SelectedIndex = -1

            VerifyCOBChanges() 'will hilight required fields

            ProcessControls(Me, False, True) ' enable UI Input elements until a row is added

        Catch ex As Exception
            Throw
        Finally

            AddButton.Enabled = True

            AddHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
            AddHandler OTH_SEXComboBox.SelectedIndexChanged, AddressOf OTH_SEXComboBox_SelectedIndexChanged
            AddHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

            COBDataGrid.Select(_COBBindingManagerBase.Position)

        End Try

    End Sub

    Private Sub DeleteMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click

        If Not COBDataGrid.IsSelected(COBDataGrid.CurrentRowIndex) Then
            MessageBox.Show(Me, "A item must be selected in the Grid before using the delete function", "Confirm Delete", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try

                RemoveHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
                RemoveHandler OTH_SEXComboBox.SelectedIndexChanged, AddressOf OTH_SEXComboBox_SelectedIndexChanged
                RemoveHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

                DeleteButton.Enabled = False

                ClearErrors()

                _COBBindingManagerBase.EndCurrentEdit()

                DeleteCOBLine()

                SaveButton.Enabled = True
                CancelButton.Enabled = True

                AddHandler OTH_RELATIONComboBox.SelectedIndexChanged, AddressOf OTH_RELATIONComboBox_SelectedIndexChanged
                AddHandler OTH_SEXComboBox.SelectedIndexChanged, AddressOf OTH_SEXComboBox_SelectedIndexChanged
                AddHandler PayerComboBox.SelectedIndexChanged, AddressOf PayerComboBox_SelectedIndexChanged

                If _COBBindingManagerBase.Count < 1 Then

                    PayerComboBox.SelectedIndex = -1
                    OTH_RELATIONComboBox.SelectedIndex = -1
                    OTH_SEXComboBox.SelectedIndex = -1

                    DeleteButton.Enabled = False
                    NextButton.Enabled = False
                    PrevButton.Enabled = False

                ElseIf _COBBindingManagerBase.Count = 0 Then

                    NextButton.Enabled = False
                    PrevButton.Enabled = False

                End If

            Catch ex As Exception
                Throw
            Finally

                If _COBBindingManagerBase.Position > -1 Then COBDataGrid.Select(_COBBindingManagerBase.Position)

            End Try
        End If

    End Sub

    Private Sub DeleteCOBLine()
        Dim DR As DataRow

        Try

            DR = DirectCast(_COBBindingManagerBase.Current, DataRowView).Row

            If DR.RowState = DataRowState.Added OrElse MessageBox.Show(Me, "Are you sure you want to DELETE the current entry?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then

                DR.Delete()

                _COBBindingManagerBase.EndCurrentEdit()

            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub AddCOBLine()

        Dim DR As DataRow

        Try

            DR = COBDS.MEDOTHER_INS.NewRow

            DR("MEDOTHER_INS_ID") = COBDS.MEDOTHER_INS.Rows.Count
            DR("FAMILY_ID") = _FamilyID
            DR("RELATION_ID") = CMSDALCommon.ToNullShortHandler(_RelationID)
            DR("OCC_FROM_DATE") = DBNull.Value
            DR("OCC_TO_DATE") = "12/31/9999" 'default date agreed upon
            DR("WORKING_SPOUSE_SW") = 0
            DR("OTH_INS_REFUSAL_SW") = 0
            DR("OTH_PAT_ACCT_NBR") = DBNull.Value
            DR("HICN") = DBNull.Value
            DR("OTH_POLICY") = DBNull.Value
            DR("OTH_TAXID") = DBNull.Value
            DR("OTH_PAYER") = DBNull.Value
            DR("OTH_SSN") = DBNull.Value
            DR("OTH_FNAME") = DBNull.Value
            DR("OTH_LNAME") = DBNull.Value
            DR("OTH_SEX") = DBNull.Value
            DR("OTH_RELATION") = DBNull.Value
            DR("OTH_DOB") = DBNull.Value
            DR("OTH_PAYER_ID") = DBNull.Value
            DR("OTH_COMMENTS") = DBNull.Value
            DR("UPDATE_REASON") = DBNull.Value
            DR("DOCID") = DBNull.Value
            DR("OTH_SUB_ACCT_NBR") = DBNull.Value
            DR("ADDRESS_LINE1") = DBNull.Value
            DR("ADDRESS_LINE2") = DBNull.Value
            DR("CITY") = DBNull.Value
            DR("STATE") = DBNull.Value
            DR("ZIP") = DBNull.Value
            DR("ZIP_4") = DBNull.Value
            DR("COUNTRY") = DBNull.Value
            DR("PHONE") = DBNull.Value
            DR("EXTENSION1") = DBNull.Value

            DR("CREATE_USERID") = _DomainUser.ToUpper
            DR("USERID") = _DomainUser.ToUpper

            COBDS.MEDOTHER_INS.Rows.Add(DR)

            SaveButton.Enabled = True
            CancelButton.Enabled = True

            OCC_FROM_DATETextBox.Focus()

            OTH_SEXComboBox.SelectedIndex = -1
            OTH_RELATIONComboBox.SelectedIndex = -1
            PayerComboBox.SelectedIndex = -1

            _COBBindingManagerBase.Position = _COBBindingManagerBase.Count - 1

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click

        Try
            SaveButton.Enabled = False 'this will reenable if the underlying dataset changes
            CancelButton.Enabled = False 'this will reenable if the underlying dataset changes

            _COBBindingManagerBase.EndCurrentEdit()

            If VerifyCOBChanges() Then
                SaveButton.Enabled = True
                CancelButton.Enabled = True
                Exit Sub
            End If

            If SaveCOBChanges() Then
                SaveButton.Enabled = True
                CancelButton.Enabled = True
                Exit Sub
            End If

        Catch ex As Exception

            SaveButton.Enabled = True 'note, this is done in the error handler just in case a failure occurs
            CancelButton.Enabled = True 'note, this is done in the error handler just in case a failure occurs

            Throw

        Finally

            If ErrorProviderErrorsList(ErrorProvider1).Length = 0 AndAlso _COBBindingManagerBase.Count > 0 Then
                _COBBindingManagerBase.Position = 0
                COBDataGrid.Select(_COBBindingManagerBase.Position)
            End If

        End Try

    End Sub

    ' Hide the tooltip if the user starts typing again before the five-second display limit on the tooltip expires.
    Private Sub OTH_DOBTextBox_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)
        Me.ToolTip1.Hide(Me.OTH_DOBTextBox)
    End Sub

    Public Shared Function ErrorProviderErrorsList(ByVal provider As ErrorProvider) As String()
        Dim ErrorsAL As New ArrayList

        Try

            ErrorProviderErrorsList(provider, provider.ContainerControl.Controls, ErrorsAL)
            Return DirectCast(ErrorsAL.ToArray(GetType(String)), String())

        Catch ex As Exception
            Throw
        End Try

    End Function

    Private Shared Sub ErrorProviderErrorsList(ByVal provider As ErrorProvider, ByVal controls As Control.ControlCollection, ByVal errors As ArrayList)
        Dim ProviderError As String
        For Each Ctrl As Control In controls
            ProviderError = provider.GetError(Ctrl)
            If ProviderError.Length > 0 Then
                errors.Add(ProviderError)
            End If

            ErrorProviderErrorsList(provider, Ctrl.Controls, errors)
        Next
    End Sub

    Private Function GetColumnDisplayName(ByVal columnName As String) As String
        Try

            If CType(ConfigurationManager.GetSection("HistoryDisplayColumnNames"), IDictionary)(ColumnName) IsNot Nothing Then
                Return CType(ConfigurationManager.GetSection("HistoryDisplayColumnNames"), IDictionary)(ColumnName).ToString
            Else
                Return ColumnName
            End If

        Catch ex As Exception
            Throw
        End Try

    End Function

    Public Function IdentifyChanges(ByVal dr As DataRow) As String

        Dim DispName As String
        Dim HistRow As String = ""

        Try

            For ColumnNum As Integer = 0 To dr.Table.Columns.Count - 1

                Try
                    DispName = GetColumnDisplayName(dr.Table.Columns(ColumnNum).ColumnName.ToUpper)
                Catch ex As Exception
                    DispName = dr.Table.Columns(ColumnNum).ColumnName.ToUpper
                End Try

                If Not dr(ColumnNum, DataRowVersion.Current).Equals(dr(ColumnNum, DataRowVersion.Original)) AndAlso DispName <> "" Then
                    HistRow &= DispName & " = " & dr(ColumnNum, DataRowVersion.Current).ToString.Trim & " (was '" & dr(ColumnNum, DataRowVersion.Original).ToString.Trim & "') " & Microsoft.VisualBasic.vbCrLf
                End If
            Next

            Return HistRow

        Catch ex As Exception
            Throw
        End Try

    End Function

    Public Function VerifyCOBChanges() As Boolean
        Dim DR As DataRow

        Try

            ClearErrors()

            If Not _ReadOnlyMode AndAlso _COBBindingManagerBase.Count > 0 AndAlso _COBBindingManagerBase.Position > -1 Then

                DR = DirectCast(_COBBindingManagerBase.Current, DataRowView).Row

                If OTH_INS_REFUSAL_SWCheckBox.Checked = False Then
                    If IsDate(DR("OCC_FROM_DATE")) Then
                    Else
                        ErrorProvider1.SetError(Me.OCC_FROM_DATETextBox, " Begin Date is invalid (mm/dd/yyyy)")
                    End If

                    If IsDate(DR("OCC_TO_DATE")) Then
                    Else
                        ErrorProvider1.SetError(Me.OCC_TO_DATETextBox, " End Date is invalid (mm/dd/yyyy)")
                    End If

                    If IsDBNull(DR("OTH_DOB")) OrElse (Not IsDBNull(DR("OTH_DOB")) AndAlso IsDate(DR("OTH_DOB"))) Then
                    Else
                        ErrorProvider1.SetError(Me.OTH_DOBTextBox, " DOB Date is invalid (mm/dd/yyyy)")
                    End If

                    If IsDate(DR("OCC_FROM_DATE")) AndAlso IsDate(DR("OCC_TO_DATE")) Then
                        If (CDate(DR("OCC_FROM_DATE")) < CDate(DR("OCC_TO_DATE"))) Then
                        Else
                            ErrorProvider1.SetError(Me.OCC_TO_DATETextBox, " End Date must be after Begin Date")
                        End If
                    End If
                End If

                If DR("PAYER_NAME").ToString.Trim.ToUpper = "OTHER" AndAlso (IsDBNull(DR("OTH_COMMENTS")) OrElse DR("OTH_COMMENTS").ToString.Trim.Length = 0) Then
                    ErrorProvider1.SetError(Me.InsurerFreeFormButton, " Must Provide a Insurer")
                End If

                If DR("PAYER_NAME").ToString.Trim.Length = 0 Then
                    ErrorProvider1.SetError(Me.PayerComboBox, " Must select a Insurer, or Non Specified")
                End If

                If ErrorProviderErrorsList(ErrorProvider1).Length > 0 Then
                    Return True
                End If
            End If

            Return False

        Catch ex As Exception
            Throw
        End Try

    End Function

    Public Sub ClearErrors()

        ErrorProvider1.SetError(OCC_TO_DATETextBox, "")
        ErrorProvider1.SetError(OCC_FROM_DATETextBox, "")
        ErrorProvider1.SetError(OTH_DOBTextBox, "")
        ErrorProvider1.SetError(InsurerFreeFormButton, "")
        ErrorProvider1.SetError(PayerComboBox, "")

    End Sub

    Public Function SaveCOBChanges() As Boolean

        Dim HistEntry As DataTable
        Dim HistRow As DataRow
        Dim ChgCnt As Integer = 0

        Dim Transaction As DbTransaction
        Dim ChangedCOBRows As UI.COBDataSet

        Try

            ChangedCOBRows = CType(COBDS.GetChanges(), UI.COBDataSet)

            If ChangedCOBRows IsNot Nothing Then

                HistEntry = New DataTable("HistoryEntries")
                HistEntry.Columns.Add("RowNum", System.Type.GetType("System.Int32"))
                HistEntry.Columns.Add("EntryPosition", System.Type.GetType("System.Int32"))
                HistEntry.Columns.Add("TransactionType", System.Type.GetType("System.Int32"))
                HistEntry.Columns.Add("Detail", System.Type.GetType("System.String"))

                Transaction = CMSDALCommon.BeginTransaction

                For Each DR As DataRow In ChangedCOBRows.Tables("MEDOTHER_INS").Rows

                    If DR.RowState <> DataRowState.Added AndAlso DR.RowState <> DataRowState.Deleted Then

                        HistRow = HistEntry.NewRow

                        HistRow("RowNum") = 0
                        HistRow("EntryPosition") = ChgCnt
                        HistRow("TransactionType") = 13
                        HistRow("Detail") = "UPDATED LINE ENTRY FOR DATE RANGE " & If(IsDBNull(DR("OCC_FROM_DATE")), "", DR("OCC_FROM_DATE")).ToString & "-" & If(IsDBNull(DR("OCC_TO_DATE")), "", DR("OCC_TO_DATE")).ToString & " Fields modified: " & IdentifyChanges(DR)

                        If IdentifyChanges(DR).ToString.Length > 0 Then 'why the row shows that it was updated I have yet to figure out :(

                            HistEntry.Rows.Add(HistRow)

                            DR("LASTUPDT") = CMSDALFDBMD.UpdateMEDOTHER_INS(CInt(DR("MEDOTHER_INS_ID")), CInt(DR("FAMILY_ID")), CShort(DR("RELATION_ID")),
                                                  CMSDALCommon.IsNullDateHandler(DR("OCC_FROM_DATE"), "OCC_FROM_DATE"), CMSDALCommon.IsNullDateHandler(DR("OCC_TO_DATE"), "OCC_TO_DATE"),
                                                  Math.Abs(CDec(DR("WORKING_SPOUSE_SW"))), Math.Abs(CDec(DR("OTH_INS_REFUSAL_SW"))),
                                                  DR("OTH_PAT_ACCT_NBR").ToString.Trim, DR("HICN").ToString.Trim, DR("OTH_POLICY").ToString.Trim,
                                                  CMSDALCommon.IsNullIntegerHandler(DR("OTH_TAXID"), "OTH_TAXID"), DR("OTH_PAYER").ToString.Trim,
                                                  CMSDALCommon.IsNullIntegerHandler(DR("OTH_SSN"), "OTH_SSN"),
                                                  DR("OTH_FNAME").ToString.Trim, DR("OTH_LNAME").ToString.Trim, TryCast(DR("OTH_SEX"), String), TryCast(DR("OTH_RELATION"), String),
                                                  CMSDALCommon.IsNullDateHandler(DR("OTH_DOB"), "OTH_DOB"), CMSDALCommon.IsNullIntegerHandler(DR("OTH_PAYER_ID"), "OTH_PAYER_ID"), DR("OTH_COMMENTS").ToString.Trim,
                                                  DR("UPDATE_REASON").ToString.Trim,
                                                  CMSDALCommon.IsNullLongHandler(DR("DOCID"), "DOCID"),
                                                  DR("OTH_SUB_ACCT_NBR").ToString.Trim,
                                                  DR("ADDRESS_LINE1").ToString.Trim, DR("ADDRESS_LINE2").ToString.Trim, DR("CITY").ToString.Trim,
                                                  DR("STATE").ToString.Trim, CMSDALCommon.IsNullIntegerHandler(DR("ZIP"), ""),
                                                  CMSDALCommon.IsNullShortHandler(DR("ZIP_4"), "ZIP_4"),
                                                  DR("COUNTRY").ToString.Trim, DR("EMAIL").ToString.Trim,
                                                  CMSDALCommon.IsNullDecimalHandler(DR("PHONE"), "PHONE"),
                                                  CMSDALCommon.IsNullShortHandler(DR("EXTENSION1"), "EXTENSION1"), DR("CONTACT1").ToString.Trim, _DomainUser.ToUpper,
                                                  CMSDALCommon.IsNullDateHandler(DR("LASTUPDT"), "LASTUPDT"), Transaction)
                            DR.EndEdit()
                            COBDS.Merge(New DataRow() {DR}, False, MissingSchemaAction.Add)
                        End If

                    ElseIf DR.RowState = DataRowState.Deleted Then 'DELETE - Note: This functionality only applies to the consoldation process which can only delete a single row

                        HistRow = HistEntry.NewRow

                        HistRow("RowNum") = 0
                        HistRow("EntryPosition") = ChgCnt
                        HistRow("TransactionType") = 14
                        HistRow("Detail") = "DELETED LINE ENTRY FOR DATE RANGE " & DR("OCC_FROM_DATE", DataRowVersion.Original).ToString & "-" & DR("OCC_TO_DATE", DataRowVersion.Original).ToString

                        HistEntry.Rows.Add(HistRow)

                        CMSDALFDBMD.DeleteMEDOTHER_INS(CInt(DR("MEDOTHER_INS_ID", DataRowVersion.Original)), Transaction)

                    ElseIf DR.RowState = DataRowState.Added Then 'ADD

                        HistRow = HistEntry.NewRow

                        HistRow("RowNum") = 0
                        HistRow("EntryPosition") = ChgCnt
                        HistRow("TransactionType") = 12
                        HistRow("Detail") = "ADDED LINE ENTRY FOR DATE RANGE " & If(IsDBNull(DR("OCC_FROM_DATE")), "", DR("OCC_FROM_DATE")).ToString & "-" & If(IsDBNull(DR("OCC_TO_DATE")), "", DR("OCC_TO_DATE").ToString)

                        HistEntry.Rows.Add(HistRow)

                        ChgCnt += 1

                        CMSDALFDBMD.CreateMEDOTHER_INS(CInt(DR("MEDOTHER_INS_ID")), CInt(DR("FAMILY_ID")), CShort(DR("RELATION_ID")),
                                                        CMSDALCommon.IsNullDateHandler(DR("OCC_FROM_DATE"), "OCC_FROM_DATE"), CMSDALCommon.IsNullDateHandler(DR("OCC_TO_DATE"), "OCC_TO_DATE"),
                                                        Math.Abs(CDec(DR("WORKING_SPOUSE_SW"))), Math.Abs(CDec(DR("OTH_INS_REFUSAL_SW"))),
                                                        TryCast(DR("OTH_PAT_ACCT_NBR"), String), TryCast(DR("HICN"), String), TryCast(DR("OTH_POLICY"), String),
                                                        CMSDALCommon.IsNullIntegerHandler(DR("OTH_TAXID"), "OTH_TAXID"),
                                                        TryCast(DR("OTH_PAYER"), String), CMSDALCommon.IsNullIntegerHandler(DR("OTH_SSN")),
                                                        TryCast(DR("OTH_FNAME"), String), TryCast(DR("OTH_LNAME"), String), TryCast(DR("OTH_SEX"), String), TryCast(DR("OTH_RELATION"), String),
                                                        CMSDALCommon.IsNullDateHandler(DR("OTH_DOB"), "OTH_DOB"), CMSDALCommon.IsNullIntegerHandler(DR("OTH_PAYER_ID"), "OTH_PAYER_ID"), TryCast(DR("OTH_COMMENTS"), String), TryCast(DR("UPDATE_REASON"), String),
                                                        CMSDALCommon.IsNullLongHandler(DR("DOCID"), "DOCID"),
                                                        TryCast(DR("OTH_SUB_ACCT_NBR"), String), TryCast(DR("ADDRESS_LINE1"), String), TryCast(DR("ADDRESS_LINE2"), String), TryCast(DR("CITY"), String), TryCast(DR("STATE"), String),
                                                        CMSDALCommon.IsNullIntegerHandler(DR("ZIP"), "ZIP"), CMSDALCommon.IsNullShortHandler(DR("ZIP_4"), "ZIP_4"),
                                                        TryCast(DR("COUNTRY"), String), TryCast(DR("EMAIL"), String),
                                                        CMSDALCommon.IsNullDecimalHandler(DR("PHONE"), "PHONE"), CMSDALCommon.IsNullShortHandler(DR("EXTENSION1"), "EXTENSION1"),
                                                        TryCast(DR("CONTACT1"), String),
                                                        _DomainUser.ToUpper, Transaction)
                    End If
                Next

                CreateHistory(HistEntry, Transaction)

                HistEntry.Dispose()

            End If

            CMSDALCommon.CommitTransaction(Transaction)

            Return True

        Catch ex As System.Data.DataException

            Try

                If Transaction IsNot Nothing AndAlso Transaction.Connection IsNot Nothing AndAlso Transaction.Connection.State <> ConnectionState.Closed Then
                    CMSDALCommon.RollbackTransaction(Transaction)
                End If

            Finally
            End Try

            MsgBox("COB data has been updated since being retrieved. Refresh COB data and retry action.", CType(MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, MsgBoxStyle), "Refresh required to complete action")

        Catch ex As DB2Exception When ex.Number = -803

            Try

                If Transaction IsNot Nothing AndAlso Transaction.Connection IsNot Nothing AndAlso Transaction.Connection.State <> ConnectionState.Closed Then
                    CMSDALCommon.RollbackTransaction(Transaction)
                End If

            Finally
            End Try

            ErrorProvider1.SetError(Me.OCC_FROM_DATETextBox, " Payer already used for specified period")
            ErrorProvider1.SetError(Me.OCC_TO_DATETextBox, " Payer already used for specified period")
            ErrorProvider1.SetError(Me.PayerComboBox, " Payer already used for specified period")
            MsgBox("Combination of From/To Dates and Payer already used, change a Date or Payer to continue.", MsgBoxStyle.Exclamation And MsgBoxStyle.OkOnly, "Date Range / Payer Combination already used.")

        Catch ex As Exception

            Try

                If Transaction IsNot Nothing AndAlso Transaction.Connection IsNot Nothing AndAlso Transaction.Connection.State <> ConnectionState.Closed Then
                    CMSDALCommon.RollbackTransaction(Transaction)
                End If

            Finally
            End Try

            Throw

        Finally
            If Transaction IsNot Nothing Then Transaction.Dispose()
            Transaction = Nothing

            HistEntry = Nothing

        End Try
    End Function

    Public Sub CreateHistory(ByRef histEntry As DataTable, ByRef transaction As DbTransaction)

        Try

            For Each DR As DataRow In HistEntry.Rows

                CMSDALFDBMD.CreateHistory(CInt(DR("TRANSACTIONTYPE")), _FamilyID, CShort(If(_RelationID Is Nothing, 0S, _RelationID)), CStr(DR("Detail")), _DomainUser.ToUpper, transaction)

            Next

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub InsurerFreeFormButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsurerFreeFormButton.Click

        Dim DR As DataRow
        Dim InsurerPayerDialog As InsurerPayerDialog

        Try
            If _COBBindingManagerBase.Count > 0 Then

                DR = DirectCast(_COBBindingManagerBase.Current, DataRowView).Row
                InsurerPayerDialog = New InsurerPayerDialog

                InsurerPayerDialog.PayerFreeTextBox.Text = DR("OTH_COMMENTS").ToString()

                Select Case InsurerPayerDialog.ShowDialog
                    Case Windows.Forms.DialogResult.OK
                        DR("OTH_COMMENTS") = InsurerPayerDialog.PayerFreeTextBox.Text

                End Select

                If DR("PAYER_NAME").ToString.Trim.ToUpper = "OTHER" AndAlso (IsDBNull(DR("OTH_COMMENTS")) OrElse DR("OTH_COMMENTS").ToString.Trim.Length = 0) Then
                    ErrorProvider1.SetError(Me.InsurerFreeFormButton, " Must Provide a Insurer")
                Else
                    ErrorProvider1.SetError(Me.InsurerFreeFormButton, "")
                End If

            End If
        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click

        Try
            CancelButton.Enabled = False

            ClearErrors()

            _COBBindingManagerBase.EndCurrentEdit()

            COBDS.Tables("MEDOTHER_INS").RejectChanges()

            _COBBindingManagerBase.EndCurrentEdit()

            COBDataGrid.RefreshData()

            SetNonBoundItems()

        Catch ex As Exception
            Throw
        Finally
            CancelButton.Enabled = False
            SaveButton.Enabled = False

            If _COBBindingManagerBase IsNot Nothing AndAlso _COBBindingManagerBase.Count > 0 Then
                _COBBindingManagerBase.Position = 0
                COBDataGrid.Select(_COBBindingManagerBase.Position)
            End If

        End Try

    End Sub

    Private Sub CheckBox_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OTH_INS_REFUSAL_SWCheckBox.CheckStateChanged, WORKING_SPOUSE_SWCheckBox.CheckStateChanged

        Try

            If _COBBindingManagerBase IsNot Nothing AndAlso _COBBindingManagerBase.Count > 0 Then
                _COBBindingManagerBase.EndCurrentEdit()
                COBDataGrid.RefreshData()
            End If

            VerifyCOBChanges()

        Catch ex As Exception
            Throw
        Finally

        End Try

    End Sub

    Private Sub NumericOnlyTextBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles EXTENSION1TextBox.KeyPress, DOCIDTextBox.KeyPress, PHONETextBox.KeyPress, ZIPTextBox.KeyPress, ZIP_4TextBox.KeyPress
        If Char.IsDigit(e.KeyChar) OrElse Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

#End Region

#Region "Formatting"

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' adjusts date values entered for a databinding
    ' </summary>
    ' <param name="sender"></param>
    ' <param name="e"></param>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[nick snyder]	8/16/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------

    Private Sub ZIPBinding_BindingComplete(ByVal sender As Object, ByVal e As BindingCompleteEventArgs)
        Try

            If e.BindingCompleteState <> BindingCompleteState.Success Then
                ErrorProvider1.SetError(CType(e.Binding.BindableComponent, Control), "ZIP format invalid. Must be 5 digits including leading zeroes (ie 01234)")
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' adjusts date values entered for a databinding
    ' </summary>
    ' <param name="sender"></param>
    ' <param name="e"></param>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[nick snyder]	8/16/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------

    Private Sub DateOnlyBinding_BindingComplete(ByVal sender As Object, ByVal e As BindingCompleteEventArgs)
        Try
            ErrorProvider1.SetError(CType(e.Binding.BindableComponent, Control), "")

            If e.BindingCompleteState <> BindingCompleteState.Success Then
                ErrorProvider1.SetError(CType(e.Binding.BindableComponent, Control), "Date format invalid. Use mmddyy or mmddyyyy")
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub DateOnlyBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try

            If IsDBNull(e.Value) = False AndAlso Not IsDate(e.Value) Then
                If IsNumeric(e.Value) Then
                    Select Case e.Value.ToString.Trim.Length
                        Case Is = 8
                            e.Value = Microsoft.VisualBasic.Left(e.Value.ToString, 2) & "-" & Microsoft.VisualBasic.Mid(e.Value.ToString, 3, 2) & "-" & Microsoft.VisualBasic.Right(e.Value.ToString, 4)
                        Case Is = 6
                            e.Value = Microsoft.VisualBasic.Left(e.Value.ToString, 2) & "-" & Microsoft.VisualBasic.Mid(e.Value.ToString, 3, 2) & "-" & Microsoft.VisualBasic.Right(e.Value.ToString, 2)
                        Case Is = 4
                            e.Value = Microsoft.VisualBasic.Left(e.Value.ToString, 1) & "-" & Microsoft.VisualBasic.Mid(e.Value.ToString, 2, 1) & "-" & Microsoft.VisualBasic.Right(e.Value.ToString, 2)
                    End Select

                ElseIf CStr(e.Value).Trim.Length = 0 Then
                    e.Value = System.DBNull.Value
                End If
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' formats date values entered for a databinding
    ' </summary>
    ' <param name="sender"></param>
    ' <param name="e"></param>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[nick snyder]	8/16/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------
    Private Sub DateOnlyBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False Then
                e.Value = Convert.ToDateTime(String.Format("{0:MM-dd-yyyy}", e.Value)) 'handles mmddyy entry
                e.Value = Format(e.Value, "MM-dd-yyyy")
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub UCaseBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = CStr(e.Value).ToUpper.Trim
            Else
                e.Value = ""
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub UCaseBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try

            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = CStr(e.Value).ToUpper
            Else
                e.Value = System.DBNull.Value
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub DateBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = Convert.ToDateTime(String.Format("{0:MM/dd/yyyy}", e.Value))
            Else
                e.Value = ""
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub DateBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = CStr(e.Value).ToUpper
            Else
                e.Value = System.DBNull.Value
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub SEXBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try

            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                Select Case e.Value.ToString
                    Case "M"
                        e.Value = "Male"
                    Case "F"
                        e.Value = "Female"
                    Case Else
                        e.Value = ""
                End Select
            Else
                e.Value = ""
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub SEXBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = CStr(e.Value).ToUpper
            Else
                e.Value = System.DBNull.Value
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub StateBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = CStr(e.Value).ToUpper
            Else
                e.Value = ""
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub StateBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso CStr(e.Value).Trim <> "" Then
                e.Value = CStr(e.Value).ToUpper
            Else
                e.Value = System.DBNull.Value
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub SSNBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = False Then
                e.Value = UnFormatSSN(e.Value.ToString)
            End If

            If e.Value.ToString.Trim.Length = 0 Then e.Value = System.DBNull.Value

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub CheckBoxBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) Then
                Select Case CInt(e.Value)
                    Case 0
                        e.Value = False
                    Case 1
                        e.Value = True
                End Select
            Else
                e.Value = False
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub CheckBoxBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = True Then
                e.Value = 1
            Else
                e.Value = 0
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub TAXIDBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = True Then
                e.Value = FormatTAXID(e.Value.ToString)
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub TAXIDBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = False Then
                e.Value = UnFormatTAXID(e.Value.ToString)
            Else
                e.Value = System.DBNull.Value
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub LeadingZeroesSize5Binding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = True Then
                e.Value = CInt(e.Value).ToString("D5")
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub LeadingZeroesSize4Binding_format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = True Then
                e.Value = CInt(e.Value).ToString("D4")
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub Numeric2NullBinding_Parse(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try

            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = False Then
                e.Value = System.DBNull.Value
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub SSNBinding_Format(ByVal sender As Object, ByVal e As System.Windows.Forms.ConvertEventArgs)
        Try
            If IsDBNull(e.Value) = False AndAlso IsNumeric(e.Value) = True Then
                e.Value = FormatSSN(e.Value.ToString)
            End If
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Public Shared Function FormatSSN(ByVal strSSN As String) As String
        Dim StrTemp As String

        Try

            StrTemp = UnFormatSSN(strSSN)
            If StrTemp.Trim <> "" Then
                Return Microsoft.VisualBasic.Left(StrTemp, 3) & "-" & Microsoft.VisualBasic.Mid(StrTemp, 4, 2) & "-" & Microsoft.VisualBasic.Right(StrTemp, 4)
            End If

            Return ""

        Catch ex As Exception
            Throw
        End Try

    End Function

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' unformats an ssn
    ' </summary>
    ' <param name="strSSN"></param>
    ' <returns></returns>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[nick snyder]	8/16/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------
    Public Shared Function UnFormatSSN(ByVal strSSN As String) As String

        Try

            If Replace(Replace(Replace(strSSN, " ", ""), "-", ""), "/", "") <> "" Then
                Return Format(CInt(Replace(Replace(Replace(strSSN, " ", ""), "-", ""), "/", "")), "0########")
            End If

            Return ""

        Catch ex As Exception
            Throw
        End Try

    End Function

    Public Shared Function FormatTAXID(ByVal strTAXID As String) As String
        Dim StrTemp As String

        StrTemp = UnFormatTAXID(strTAXID)
        If StrTemp.Trim <> "" Then
            Return Microsoft.VisualBasic.Left(StrTemp, 2) & "-" & Microsoft.VisualBasic.Mid(StrTemp, 3, 7)
        Else
            Return ""
        End If
    End Function

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' unformats an ssn
    ' </summary>
    ' <param name="strSSN"></param>
    ' <returns></returns>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	[nick snyder]	8/16/2006	Created
    ' </history>
    ' -----------------------------------------------------------------------------
    Public Shared Function UnFormatTAXID(ByVal strTAXID As String) As String
        Try

            If Replace(Replace(Replace(strTAXID, " ", ""), "-", ""), "/", "") <> "" Then
                Return Format(CLng(Replace(Replace(Replace(strTAXID, " ", ""), "-", ""), "/", "")), "0########")
            End If

            Return ""

        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Sub AllowOnlyNumeric_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DOCIDTextBox.TextChanged, PHONETextBox.TextChanged, EXTENSION1TextBox.TextChanged, ZIP_4TextBox.TextChanged, ZIPTextBox.TextChanged

        Dim TBox As TextBox
        Dim IntCnt As Integer
        Dim StrTmp As String

        Try

            TBox = CType(sender, TextBox)

            If IsNumeric(TBox.Text) = False Andalso Len(TBox.Text) > 0 Then
                StrTmp = TBox.Text
                For IntCnt = 1 To Len(StrTmp)
                    If IsNumeric(Mid(StrTmp, IntCnt, 1)) = False AndAlso Len(StrTmp) > 0 AndAlso Mid(StrTmp, IntCnt, 1) <> "-" Then
                        StrTmp = Replace(StrTmp, Mid(StrTmp, IntCnt, 1), "")
                    End If
                Next
                TBox.Text = StrTmp
            End If

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub ZIPTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ZIPTextBox.Validating

        Try

            If CType(sender, TextBox).Text.Length > 0 AndAlso Not CType(sender, TextBox).Text Like "#####" Then
                ' The Zip code is invalid.
                ' Cancel the event moving off of the control.
                e.Cancel = True

                ' Select the offending text.
                CType(sender, TextBox).Select(0, CType(sender, TextBox).Text.Length)

                ' Give the ErrorProvider the error message to
                ' display.
                ErrorProvider1.SetError(CType(sender, TextBox), "Invalid ZIP code " & "ZIP - 00000")
            Else
                ErrorProvider1.SetError(CType(sender, TextBox), "")
            End If
        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub ZIP_4TextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ZIP_4TextBox.Validating

        Try

            If CType(sender, TextBox).Text.Length > 0 AndAlso Not CType(sender, TextBox).Text Like "####" Then
                ' The Zip code is invalid.
                ' Cancel the event moving off of the control.
                e.Cancel = True

                ' Select the offending text.
                CType(sender, TextBox).Select(0, CType(sender, TextBox).Text.Length)

                ' Give the ErrorProvider the error message to
                ' display.
                ErrorProvider1.SetError(CType(sender, TextBox), "Invalid ZIP+4 code " & "ZIP+4 - 0000")
            Else
                ErrorProvider1.SetError(CType(sender, TextBox), "")
            End If
        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Sub HistoryButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HistoryButton.Click

        Dim HistoryF As History

        Try

            HistoryF = New History

            HistoryF.FamilyID = _FamilyID
            HistoryF.RelationID = _RelationID

            HistoryF.ShowDialog(Me)

        Catch ex As Exception
            Throw
        Finally
            HistoryF.Dispose()
            HistoryF = Nothing
        End Try

    End Sub

#End Region

End Class