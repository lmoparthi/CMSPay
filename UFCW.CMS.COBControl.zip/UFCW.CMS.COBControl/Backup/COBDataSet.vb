﻿Partial Class COBDataSet
End Class