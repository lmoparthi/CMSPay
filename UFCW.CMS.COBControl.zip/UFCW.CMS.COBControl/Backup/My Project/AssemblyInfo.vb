﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("UFCW.CMS.COBControl")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("UFCW/UFCW TRUST FUNDS")> 
<Assembly: AssemblyProduct("UFCW.CMS.COBControl")> 
<Assembly: AssemblyCopyright("Copyright © UFCW/UFCW TRUST FUNDS 2009")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("8b5f7d6c-b12d-4a7d-bb82-c7a9a808eca4")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.4.0.*")> 

<Assembly: NeutralResourcesLanguageAttribute("en-US")> 